T = int(input())

for tc in range(1, T+1):
    # 배열의 크기
    N = int(input())
    # 각 row에서 어떠한
    array = [list(map(int, input().split())) for i in range(N)]
    log = [] # 각 row에서 어떤 col의 값을 선택했는지를 기록한다.
    result = 0
    cand_all = []

    # 가장 먼저, 기준이 될 최소값의 합을 구한다.

    for row in range(N):
        min_value = 100
        min_idx = 0
        cand_list = []
        for col in range(N):
            if col not in log: # 최소값이 있는 col에 기록되어 있지 않으면서
                if min_value >= array[row][col]:
                    min_value = array[row][col]
                    min_idx = col
            else:
                continue

        result += min_value

    # 이제 이 최소값보다 더 작게 나올 수 있는 여지가 있는지를 확인한다.


    print(f'#{tc} {result}')
